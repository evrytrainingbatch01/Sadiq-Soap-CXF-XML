package com.evry.employee.entity.dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;

import com.evry.employee.entity.EmployeeEntity;
//@RunWith(JUnitPlatform.class)
class EmployeeDaoImplTest {

	@Autowired
	EmployeeDaoImpl employeeDao ;//= new EmployeeDaoImpl();
	EmployeeEntity empObj= new EmployeeEntity();
	
	@BeforeEach
	public  void initEmployee() {
		System.out.println(employeeDao);
		empObj.setEmployeeName("pk");
		empObj.setEmployeePhoneNumber(8900);
	}
	
	
	
	@Test
	public void testAddEmployee() {
		EmployeeEntity addEmployee = employeeDao.addEmployee(empObj);
		assertNotNull(addEmployee);
		//Assert.assertNotNull(employeeDao.addEmployee(empObj));
		//fail("Not yet implemented");
	}

/*	@Test
	void testUpdateEmployee() {
		fail("Not yet implemented");
	}

	@Test
	void testGetEmployee() {
		fail("Not yet implemented");
	}

	@Test
	void testGetAllEmployees() {
		fail("Not yet implemented");
	}

	@Test
	void testDeleteEmployee() {
		fail("Not yet implemented");
	}*/

}
