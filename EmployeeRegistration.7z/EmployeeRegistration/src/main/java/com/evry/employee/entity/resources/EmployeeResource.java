package com.evry.employee.entity.resources;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import com.evry.employee.entity.EmployeeEntity;

/**
 * 
 * @author sadiq.ahamad
 *
 */
@WebService
public interface EmployeeResource {

	@WebMethod
	public EmployeeEntity addEmployee(EmployeeEntity employeeEntity);

	@WebMethod
	public EmployeeEntity updateEmployee(EmployeeEntity employeeEntity);

	@WebMethod
	public EmployeeEntity getEmployee(int id);

	@WebMethod
	public void deleteEmployee(int id);

	@WebMethod
	public List<EmployeeEntity> getAllEmployees();

}
