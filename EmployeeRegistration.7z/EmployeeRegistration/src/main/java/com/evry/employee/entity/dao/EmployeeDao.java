package com.evry.employee.entity.dao;

import java.util.List;

import com.evry.employee.entity.EmployeeEntity;
/**
 * 
 * @author sadiq.ahamad
 *
 */
public interface EmployeeDao {

	public EmployeeEntity addEmployee(EmployeeEntity employeeEntity);

	public EmployeeEntity updateEmployee(EmployeeEntity employeeEntity);

	public EmployeeEntity getEmployee(int id);

	public List<EmployeeEntity> getAllEmployees();

	public void deleteEmployee(int id);
}
