package com.evry.employee.entity.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.evry.employee.entity.EmployeeEntity;
import com.evry.employee.entity.dao.EmployeeDao;

/**
 * 
 * @author sadiq.ahamad
 *
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

	/*
	 * @Inject private EmployeeDao employeeDao;
	 */

	// private EmployeeDao employeeDao = new EmployeeDaoImpl();

	@Autowired
	private EmployeeDao employeeDao;

	@Override
	public EmployeeEntity addEmployee(EmployeeEntity employeeEntity) {
		// TODO Auto-generated method stub
		return employeeDao.addEmployee(employeeEntity);
	}

	@Override
	public EmployeeEntity getEmployee(int id) {
		return employeeDao.getEmployee(id);
	}

	@Override
	public EmployeeEntity updateEmployee(EmployeeEntity employeeEntity) {
		return employeeDao.updateEmployee(employeeEntity);
	}

	@Override
	public void deleteEmployee(int id) {
		employeeDao.deleteEmployee(id);
	}

	@Override
	public List<EmployeeEntity> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeDao.getAllEmployees();
	}

}
