package com.evry.employee.entity.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.evry.employee.entity.EmployeeEntity;

/**
 * 
 * @author sadiq.ahamad
 *
 */
@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	// private SessionFactory factory = new
	// Configuration().configure("configuration.xml").buildSessionFactory();

	@Autowired
	private SessionFactory factory;

	public EmployeeEntity addEmployee(EmployeeEntity employeeEntity) {

		Session session = factory.openSession();
		session.beginTransaction();
		session.save(employeeEntity);
		session.getTransaction().commit();

		return employeeEntity;

	}

	@Override
	public EmployeeEntity updateEmployee(EmployeeEntity employeeEntity) {
		// TODO Auto-generated method stub

		Session session = factory.openSession();
		session.beginTransaction();
		session.saveOrUpdate(employeeEntity);
		session.getTransaction().commit();
		return employeeEntity;
	}

	@Override
	public EmployeeEntity getEmployee(int id) {
		// TODO Auto-generated method stub
		Session session = factory.openSession();
		return session.get(EmployeeEntity.class, id);

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmployeeEntity> getAllEmployees() {
		// TODO Auto-generated method stub
		Session session = factory.openSession();
		String qry = "from EmployeeEntity";
		Query query = session.createQuery(qry);
		return query.getResultList();
	}

	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		Session session = factory.openSession();
		session.beginTransaction();
		EmployeeEntity entity = session.get(EmployeeEntity.class, id);
		session.delete(entity);
		session.getTransaction().commit();
	}

}
